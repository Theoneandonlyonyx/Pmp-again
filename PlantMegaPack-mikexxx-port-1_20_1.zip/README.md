# PlantMegaPack mikexxx port (Forge 1.20.1)
Upload this folder (or the zip) to a GitHub repo -> Actions tab -> "build-jar" -> download the jar artifact.
Honeycomb on a plant = waxed (stops growing). Axe removes wax. Bone meal = +1 growth stage.

Added in this revision:
- Planters (59), flower pots (32), wall brackets (26 incl. 1.7.10 stone/gem ones), bamboo poles (9), bamboo walls (9),
  fruitwood bark, potting table (opens a 3x3 crafting grid).
- 241 crafting recipes converted from the 1.12.2 version (+ item tags food_vegetable/fruit/berry/nut/rice/bread/mushroom).
- Latin names for all species/cultivar plants (shown as grey italic tooltip).

Not ported: world generation, advancements, trellis / trellis tower (no assets in the 1.12.2 jar), curled brackets, cactus spike items.

Rev 3:
- Removed duplicate plants (same texture, different name): kept the specific 1.7.10 cultivar names, kept 1.12.2 colours only where 1.7.10 has none.
  Flowers are sorted by plant, then rainbow order (dark red -> red -> coral -> orange -> yellow -> green -> cyan -> blue -> royal -> purple -> magenta -> pink -> white).
- Tall plants are separate blocks: 1.12.2 3-segment plants = Bottom / Middle / Top blocks, 2-block plants = Bottom / Top blocks,
  1.7.10 plants with 6/8/10 stage textures = one block per stage (Stage 1..n). Plants with 2-5 stages still grow with bone meal.
- Epiphytes (18) are wall-mounted blocks that attach to the side of logs/blocks.

Rev 4:
- Medium / large plants are ONE block + ONE item again. 1.7.10 'DOUBLE' plants (taken from the jar's plant table): 2 single-block stages, then
  bottom/top pairs from stage 3 on (growing via bone meal / random ticks, the top is placed when it reaches a 2-block stage). 1.12.2 large plants
  (3 segments, 2 wide) and 2-segment plants use the jar's own models. Honeycomb waxes all segments, axe removes the wax.
- Stage-split entries removed: every single-block growth plant is one inventory item.
- Berry bushes: right-click when fully grown -> berries drop, the bush goes back to an earlier stage.
- Flowers tab: rainbow-order colour flowers first, then flowers with colour families kept together in rainbow order.
- All mod tabs are chained so they sit next to each other.
